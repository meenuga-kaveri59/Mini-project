import art
def add(n1, n2):
    return n1 + n2

def sub(n1, n2):
    return n1 - n2

def mul(n1, n2):
    return n1 * n2

def div(n1, n2):
    return n1 / n2

operations = {
    "+":add,
    "-":sub,
    "*":mul,
    "/":div
}
def calculator():
    print(art.logo)
    should_accumulate=True
    num1=float(input("Enter the first number: "))
    while should_accumulate:
        for symbol in operations:
            print(symbol)
        operator=input("Select an operation: ")
        num2=float(input("Enter the second number: "))
        answer = operations[operator](num1,num2)
        print(f"{num1} {operator} {num2} = {answer}")
        choice = input(f"Type 'y' to continue calculation with {answer}. or 'n' to start the new calculation ").lower()

        if choice == "y":
            num1=answer
        else:
            should_accumulate = False
            print("\n" * 20)
            calculator()


calculator()