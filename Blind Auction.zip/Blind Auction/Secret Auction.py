# TODO-1: Ask the user for input
# TODO-2: Save data into dictionary {name: price}
# TODO-3: Whether if new bids need to be added
# TODO-4: Compare bids in dictionary


from art import logo
print(logo)

def highest_bidder(bidden_dictionary):
    winner=""
    highest_bid=0

    max(bidden_dictionary)

    for bidder in bidden_dictionary:
        bid_amount=bidden_dictionary[bidder]
        if bid_amount > highest_bid:
            highest_bid= bid_amount
            winner = bidder
    print(f"The winner is {winner} with the ${highest_bid}")

    # (or)
    #max(dictionary_name,key=dictionary_name.get)


Bid={}
Continue_bidding=True
while Continue_bidding:
    Name = input("What is Your Name?")
    Price = int(input("What is your bid?: $"))
    Bid[Name] = Price
    Should_continue = input("Are there any other bidders? Type 'yes or 'no'.").lower()
    if Should_continue == "no":
        continue_bidding = False
        highest_bidder(Bid)
    elif Should_continue == "yes":
        print("\n" * 100)
